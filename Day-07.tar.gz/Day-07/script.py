#!/usr/bin/env python3

# Python script example
print("Hello from script.py")
