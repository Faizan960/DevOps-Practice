#!/bin/bash

# Bash script example
echo "Hello from file2.sh"
