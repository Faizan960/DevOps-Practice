#!/bin/bash

greet() {
           echo "Hello $1!!!!!!!!!! Welcome to DevOps!!!"
}

greet "Faizan
" 

