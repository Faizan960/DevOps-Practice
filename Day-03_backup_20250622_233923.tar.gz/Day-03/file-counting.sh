#!/bin/bash

echo "Listing all .sh files present in current directory"
for file in *.sh
do 
   echo "$file"
done
